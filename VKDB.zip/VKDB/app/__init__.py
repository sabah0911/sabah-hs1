import os
from dotenv import load_dotenv
from flask import Flask
from flask_login import current_user

# 1. Load .env from project root
basedir = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(basedir, '..', '.env'))

from .extensions import db, migrate, login_manager, bcrypt

def create_app(config_object="app.config"):
    # 2. Create app, pointing at the correct template/static folders
    app = Flask(
        __name__,
        template_folder=os.path.join(basedir, 'templates'),
        static_folder=os.path.join(basedir, 'static')
    )
    app.url_map.strict_slashes = False

    # 3. Load configuration (including DATABASE_URL, SECRET_KEY)
    app.config.from_object(config_object)

    # 4. Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    bcrypt.init_app(app)

    # 5. Set the login view for @login_required
    login_manager.login_view = 'auth.login'

    # 6. Import models so that Flask-Migrate sees them
    #    (you don’t have to use them here)
    from .models.user       import User
    from .models.prediction import Prediction
    from .models.contact    import Contact

    # 7. Register your blueprints
    from .blueprints.auth   import auth_bp
    from .blueprints.public import public_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(public_bp)

    # 8. Inject current_user into all templates
    @app.context_processor
    def inject_base_parameters():
        return dict(current_user=current_user)

    return app
