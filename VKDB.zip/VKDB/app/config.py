import os
from dotenv import load_dotenv

# 1. Locate and load the .env file (one level up from app/)
basedir = os.path.abspath(os.path.dirname(__file__))
env_path = os.path.join(basedir, '..', '.env')
load_dotenv(env_path)

# 2. Database: use Supabase if set, otherwise fall back to local SQLite
SQLALCHEMY_DATABASE_URI = os.getenv(
    'DATABASE_URL',
    'sqlite:///' + os.path.join(basedir, 'data.sqlite')
)

# 3. Secret key for sessions & Flask-Login
SECRET_KEY = os.getenv('FLASK_SECRET', 'you-should-change-this-default')

# 4. Standard SQLAlchemy setting
SQLALCHEMY_TRACK_MODIFICATIONS = False

# 5. Uploads directory (can override from .env)
UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', 'uploads')
