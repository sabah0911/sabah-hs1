import pickle
import numpy as np

from flask import (
    render_template, request,
    redirect, url_for, jsonify, flash
)
from flask_login import login_required, current_user

from app.extensions import db
from app.models.prediction import Prediction
from app.models.contact    import Contact
from . import public_bp

# Load your trained model and scaler once at import time
model  = pickle.load(open('random_forest_model.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl',           'rb'))

# ——— Home & About ———————————————————————————————————————
@public_bp.route('/')
def index():
    return render_template('index.html')

@public_bp.route('/about-us')
def about_us():
    return render_template('about.html')


# ——— Prediction UI —————————————————————————————————————
@public_bp.route('/prediction')
@login_required
def prediction_page():
    return render_template('prediction.html')


# ——— Predict API ——————————————————————————————————————
@public_bp.route('/predict', methods=['POST'])
@login_required
def predict():
    try:
        data = request.get_json()
        # parse inputs
        age  = float(data['age'])
        sbp  = float(data['systolicBP'])
        dbp  = float(data['diastolicBP'])
        bs   = float(data['bs'])
        bt   = float(data['bodyTemp'])
        hr   = float(data['heartRate'])

        # predict
        features     = np.array([[age, sbp, dbp, bs, bt, hr]])
        pred_numeric = model.predict(features)[0]
        risk_map     = {0: "Low Risk", 1: "Mid Risk", 2: "High Risk"}
        result       = risk_map.get(pred_numeric, "Unknown")

        # save to DB
        new_pred = Prediction(
            user_id      = current_user.id,
            age          = age,
            systolic_bp  = sbp,
            diastolic_bp = dbp,
            bs           = bs,
            body_temp    = bt,
            heart_rate   = hr,
            result       = result
        )
        db.session.add(new_pred)
        db.session.commit()

        return jsonify({'result': result})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ——— Contact Us ——————————————————————————————————————
@public_bp.route('/contact-us', methods=['GET','POST'])
def contact_us():
    if request.method == 'POST':
        # gather form data
        name    = request.form.get('name')
        email   = request.form.get('email')
        phone   = request.form.get('phone')
        subject = request.form.get('subject')
        message = request.form.get('message')

        # persist
        new_msg = Contact(
            name    = name,
            email   = email,
            phone   = phone,
            subject = subject,
            message = message
        )
        db.session.add(new_msg)
        db.session.commit()

        flash("Your message has been sent!", "success")
        return render_template('contact.html', success=True)

    return render_template('contact.html')
