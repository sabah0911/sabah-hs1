from flask import render_template, redirect, url_for, request
from flask_login import login_user, logout_user, login_required, current_user
from app.extensions import db, bcrypt
from app.models.user import User
from . import auth_bp

# ----------------- LOGIN -----------------
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    message = None

    if request.method == 'POST':
        # 1) Get form fields
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        # 2) Fetch the user
        user = User.query.filter_by(email=email).first()

        # 3) Verify password & log in
        if user and user.verify_password(password):
            login_user(user)
            return redirect(url_for('public.prediction_page'))
        else:
            message = "Invalid email or password"

    return render_template('log-in.html', message=message)


# ----------------- REGISTER -----------------
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    message = None

    if request.method == 'POST':
        # 1) Get form fields
        first_name = request.form.get('first_name', '').strip()
        last_name  = request.form.get('last_name',  '').strip()
        email      = request.form.get('email',      '').strip().lower()
        password   = request.form.get('password',   '')
        confirm    = request.form.get('confirm_password', '')

        # 2) Basic validation
        if not all([first_name, last_name, email, password, confirm]):
            message = "Please fill in all fields"
        elif password != confirm:
            message = "Passwords do not match"
        else:
            # 3) Create user
            new_user = User(
                first_name=first_name,
                last_name=last_name,
                email=email
            )
            new_user.password = password   # password setter hashes it
            db.session.add(new_user)
            try:
                db.session.commit()
                message = "Registration successful! Please log in."
                return redirect(url_for('auth.login'))
            except Exception:
                db.session.rollback()
                message = "Email already registered"

    return render_template('register.html', message=message)


# ----------------- LOGOUT -----------------
@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('public.index'))


# ----------------- FORGET PASSWORD -----------------
@auth_bp.route('/forget-password')
def forget_password():
    if current_user.is_authenticated:
        return redirect(url_for('public.index'))
    return render_template('forget-password.html')
