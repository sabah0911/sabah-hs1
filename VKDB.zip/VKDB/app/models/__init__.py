from .user import User
from .prediction import Prediction  # ✅ add this
