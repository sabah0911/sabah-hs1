from flask_login import UserMixin
from sqlalchemy import func

from app.extensions import db, login_manager, bcrypt


# Flask-Login user loader
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class User(db.Model, UserMixin):
    __tablename__ = 'users'

    id            = db.Column(db.BigInteger, primary_key=True)
    first_name    = db.Column(db.Text,      nullable=False)
    last_name     = db.Column(db.Text,      nullable=False)
    email         = db.Column(db.Text,      unique=True, nullable=False)
    password_hash = db.Column(db.Text,      nullable=False)
    created_at    = db.Column(
        db.DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    @password.setter
    def password(self, password):
        # hash + decode to UTF-8 string
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def verify_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)
