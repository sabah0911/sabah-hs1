from sqlalchemy import func
from app.extensions import db

class Prediction(db.Model):
    __tablename__  = 'predictions'

    id             = db.Column(db.BigInteger, primary_key=True)
    user_id        = db.Column(db.BigInteger, db.ForeignKey('users.id'))
    age            = db.Column(db.Integer, nullable=False)
    systolic_bp    = db.Column(db.Numeric, nullable=False)
    diastolic_bp   = db.Column(db.Numeric, nullable=False)
    bs             = db.Column(db.Numeric, nullable=False)
    body_temp      = db.Column(db.Numeric, nullable=False)
    heart_rate     = db.Column(db.Numeric, nullable=False)
    result         = db.Column(db.Text,    nullable=False)
    created_at     = db.Column(
        db.DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
