from sqlalchemy import func
from app.extensions import db

class Contact(db.Model):
    __tablename__  = 'contacts'

    id             = db.Column(db.BigInteger, primary_key=True)
    name           = db.Column(db.Text,    nullable=False)
    email          = db.Column(db.Text,    nullable=False)
    phone          = db.Column(db.Text)
    subject        = db.Column(db.Text,    nullable=False)
    message        = db.Column(db.Text,    nullable=False)
    created_at     = db.Column(
        db.DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
